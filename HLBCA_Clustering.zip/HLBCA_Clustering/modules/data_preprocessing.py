import pandas as pd

def load_data(file_path):
    """ Load dataset from CSV file."""
    try:
        data = pd.read_csv(file_path)
        print("Dataset loaded successfully.")
        return data
    except Exception as e:
        print(f"Error loading dataset: {e}")
        return None
